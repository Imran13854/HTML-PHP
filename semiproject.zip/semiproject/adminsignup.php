<html>
	<body>
		<?php
		$err_fname="";
		$fname="";
		$err_lname="";
		$lname="";
		$err_uname="";
		$uname="";
		$err_email="";
		$email="";
		$err_address1="";
		$address1="";
		$err_address2="";
		$address2="";
		$err_city="";
		$city="";
		$err_state="";
		$state="";
		$err_zip="";
		$zip="";
		$err_phone="";
		$phone="";
		$err_month="";
		$month="";
		$err_day="";
		$day="";
		$err_year="";
		$year="";
		$err_pass="";
		$pass="";
		$err_confpass="";
		$confpass="";
		
		if(isset($_POST['submit']))
		{
			
			if(empty($_POST['fname']))
			{
				$err_fname="*First Name Required";
			}
			else
			{			
				$fname=htmlspecialchars($_POST['fname']);
				echo "$fname ";
			}
			if(empty($_POST['lname']))
			{
				$err_lname="*Last Name Required";
			}
			else
			{			
				$lname=htmlspecialchars($_POST['lname']);
				echo "$lname<br>";
			}
			if(empty($_POST['uname']))
			{
				$err_uname="*Username Required";
			}
			else
			{			
				$uname=htmlspecialchars($_POST['uname']);
				echo "$uname<br>";
			}
			if(empty($_POST['email']))
			{
				$err_email="*E-mail Required";
			}
			else
			{
				$email=htmlspecialchars($_POST['email']);
				if (!filter_var($email, FILTER_VALIDATE_EMAIL))
				{
					$err_email = "Invalid email format";
				}
				else
				{
					echo "$email<br>";
				}
			}
			if(empty($_POST['address1']))
			{
				$err_address1="*Address Required";
			}
			else
			{
				$address1=htmlspecialchars($_POST['address1']);
				echo "$address1<br>";
			}
			if(empty($_POST['address2']))
			{
				$err_address2="*Address Required";
			}
			else
			{
				$address2=htmlspecialchars($_POST['address2']);
				echo "$address2<br>";
			}
			if(empty($_POST['city']))
			{
				$err_city="*City Required";
			}
			else
			{
				$city=htmlspecialchars($_POST['city']);
				echo "$city<br>";
			}
			if(empty($_POST['state']))
			{
				$err_state="*State Required";
			}
			else
			{
				$state=htmlspecialchars($_POST['state']);
				echo "$state<br>";
			}
			if(empty($_POST['zip']))
			{
				$err_zip="*Zip code Required";
			}
			else
			{
				$zip=htmlspecialchars($_POST['zip']);
				echo "$zip<br>";
			}
			if (empty($_POST['phone']))
			{
				$err_phone="*Phone number Required";
			}
			else
			{
				$phone=htmlspecialchars($_POST['phone']);
				$phone=$_POST['phone'];
				
				if (strlen($phone)==11){
				
					echo "$phone<br>";
				}
				else{
					$err_phone="*Invalid Phone number";
				}
			}
			if(strlen($_POST['month'])>2)
			{
				$err_month="*Month Required";
			}
			else
			{
				$month=htmlspecialchars($_POST['month']);
				echo "$month";
			}
			if(empty($_POST['pass']))
			{
				$err_pass="*Password Required";
			}
			else
			{
				$pass=htmlspecialchars($_POST['pass']);
				$pass=$_POST['pass'];
				
				if (strlen($pass)>=8){
				
					echo "$pass<br>";
				}
				else{
					$err_pass="*Password must contain more than 8 char or digits";
				}
			}
			if(empty($_POST['confpass']))
			{
				$err_confpass="*Password Required";
			}
			else
			{
				$confpass=htmlspecialchars($_POST['confpass']);
				$confpass=$_POST['confpass'];
				if(strlen($confpass)<8)
				{
					$err_confpass="*Password must contain more than 8 char or digits";
				}
				else
				{
				if ($confpass == $pass){
				
					echo "$confpass <br>";
				}
				else{
					$err_confpass="*Password doesn't match";
				}
				}
			}
			
			
		}
		?>
	
		<title>Signup</title>
		<br> 
		<form method="post" action="">
			<center>
				<table bgcolor="#479059" width="500">
					<tr>
						<td align="center">
							<table>
								<tr>
									<td align="left">
										<br><span style="color:white";><h2>Signup now</h2></span>
									</td>
								</tr>
								<tr>
									<td align="left">
										<span style="color:white";><h4>Creating an account is free...</h4></span>
									</td>
								</tr>
								
								<tr>
									<td align="left">
										<span style="color:white";>First Name</span>
									</td>
								</tr>
								<tr>
									<td align="left">
										<input type="text" value="<?php echo $fname;?>" name="fname" style="height: 27px;width: 250px"> 
										<br><small><small><span style="color:yellow"><?php echo $err_fname;?></span></small></small>
									</td>
								</tr>
								<tr>
									<td align="left">
										 <br><span style="color:white";>Last Name</span>
									</td>
								</tr>
								<tr>
									<td align="left">
										<input type="text" value="<?php echo $lname;?>" name="lname" style="height: 27px;width: 250px">
										<br><small><small><span style="color:yellow"><?php echo $err_lname;?></span></small></small>
									</td>
								</tr>
								<tr>
									<td align="left">
										 <br><span style="color:white";>Username</span>
									</td>
								</tr>
								<tr>
									<td align="left">
										<input type="text" value="<?php echo $uname;?>" name="uname" style="height: 27px;width: 250px">
										<br><small><small><span style="color:yellow"><?php echo $err_uname;?></span></small></small>
									</td>
								</tr>
								<tr>
									<td align="left">
										<br><span style="color:white";>E-mail</span>
									</td>
								</tr>
								<tr>
									<td align="left">
										<input type="text" value="<?php echo $email;?>" name="email"style="height: 27px;width: 250px">
										<br><small><small><span style="color:yellow"><?php echo $err_email;?></span></small></small>
									</td>
								</tr>
								<tr>
									<td align="left">
										<br><span style="color:white";>Address</span>
									</td>
								</tr>
								<tr>
									<td align="left">
										<input type="text" value="<?php echo $address1;?>" name="address1" style="height: 27px;width: 250px">
										<br><small><small>Present Address<small></small>
										&nbsp <small><span style="color:yellow"><?php echo $err_address1;?></span></small>
									</td>
								</tr>
								<tr>
									<td align="left">
										<input type="text" value="<?php echo $address2;?>" name="address2" style="height: 27px;width: 250px">
										<br><small><small>Permanent Address<small></small>
										&nbsp <small><span style="color:yellow"><?php echo $err_address2;?></span></small>
										
									</td>
								</tr>
								<tr>
									<td align="left">
										<br><span style="color:white";>City</span>
										
									</td>
								</tr>
								<tr>
									<td align="left">
										<input type="text" value="<?php echo $city;?>" name="city" style="height: 27px;width: 250px">
										<br><small><small><span style="color:yellow"><?php echo $err_city;?></span></small></small>
										
									</td>
								</tr>
								<tr>
									<td align="left">
										<br><span style="color:white";>State</span>
									</td>
								</tr>
								<tr>
									<td align="left">
										<input type="text" value="<?php echo $state;?>" name="state" style="height: 27px;width: 250px">
										<br><small><small><span style="color:yellow"><?php echo $err_state;?></span></small></small>
									</td>
								</tr>
								<tr>
									<td align="left">
										<br><span style="color:white";>Zip/Postal Code</span>
									</td>
								</tr>
								<tr>
									<td align="left">
										<input type="text" value="<?php echo $zip;?>" name="zip" style="height: 27px;width: 250px">
										<br><small><small><span style="color:yellow"><?php echo $err_zip;?></span></small></small>
									</td>
								</tr>
								<tr>
									<td align="left">
										<br><span style="color:white";>Phone</span>
									</td>
								</tr>
								<tr>
									<td align="left">
										<input type="text" value="<?php echo $phone;?>" name="phone" style="height: 27px;width: 250px">
										<br><small><small><span style="color:yellow"><?php echo $err_phone;?></span></small></small>
									</td>
								</tr>
								<tr>
									<td align="left">
										<br><span style="color:white";>Date of Birth</span>
									</td>
								</tr>
								
								<tr>
									<td align="left">
										<select name = "month" style="height: 25px;width: 81px">
											<option>Month</option>
											<?php
												for($month = 1; $month <= 12; $month++){
												echo"<option value = '".$month."'>".$month."</option>";
												}
											?>
											<br><small><small><span style="color:yellow"><?php echo $err_month;?></span></small></small>
										</select>
										<select name = "day" style="height: 25px;width: 81px">
											<option>Day</option>
											<?php
												for($day = 1; $day <= 31; $day++){
												   echo "<option value = '".$day."'>".$day."</option>";
												}
										   ?>
										</select>
										<select name = "Year" style="height: 25px;width: 81px">
											<option>Year</option>
											<?php
												for($year = 2019; $year >= 1900; $year--){
												   echo "<option value = '".$year."'>".$year."</option>";
												}
										   ?>
										</select>
										
									</td>
								</tr>
								<tr>
									<td align="left">
										<br><span style="color:white";>Password</span>
									</td>
								</tr>
								<tr>
									<td align="left">
										<input type="password" value="<?php echo $pass;?>" name="pass" style="height: 27px;width: 250px">
										<br><small><small><span style="color:yellow"><?php echo $err_pass;?></span></small></small>
										
									</td>
								</tr>
								<tr>
									<td align="left">
										<br><span style="color:white";>Confirm Password</span>
									</td>
								</tr>
								<tr>
									<td align="left">
										<input type="password" name="confpass" style="height: 27px;width: 250px">
										<br><small><small><span style="color:yellow"><?php echo $err_confpass;?></span></small></small>
										
									</td>
								</tr>
									
								<tr>
									<td align="center">
										<br><br><input type="submit" value="Submit" name="submit" style="height: 27px;width: 250px;background-color:#ff4e00; border-color:blue;color:white;">
										
										
									</td>
								</tr>
								<tr>
									<td align="center">
										<span style="color:white";>Already have an account? <a href="login.php">Login</a></span>
										<br><br><br>
									</td>
								</tr>
							
							</table>
						</td>
					</tr>
				</table>
			</center>
		</form>
	</body>
</html>