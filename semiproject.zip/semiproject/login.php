<?php
	session_start();
	
	if(isset($_COOKIE['loggedinuser']))
	{
		
		setcookie("loggedinuser"," ",time()-240);
	}
?>

<html>
	<?php
		$err_uname="";
		$uname="";
		$err_pass="";
		$pass="";
		$err_invalid="";
		$has_error=false;
		
		if(isset($_POST['login']))
		{
			if(empty($_POST['uname']))
			{
				$err_uname="*Username Required";
				$has_error=true;
			}
			else
			{
				$uname=htmlspecialchars($_POST['uname']);
				
			}
			if(empty($_POST['pass']))
			{
				$err_pass="*Password Required";
				$has_error=true;
			}
			else
			{
				$pass=htmlspecialchars($_POST['pass']);
				
			}
			if(!$has_error)
			{
				if($uname == "Imran" && $pass=="12345678")
				{
					session_start();
					setcookie("loggedinuser",$uname,time()+240);
					//$_SESSION["loggedinuser"]=$uname;
					header("Location:Homepage.php");
				}
				else
				{
					$err_invalid="Invalid Username or Password";
					//echo $err_invalid;
				}
			}
		}
	
	?>

	<title>Login</title>

	<body>
		<br> <br> <br> <br> <br> <br>
		<form method="POST" action="">
			<center>
				<table bgcolor="#479059" width="400">
					<tr>
						<td>
							<center>
								<table>
									<tr>
										<td align="center">
											<br><span style="color:white";><h2>Login Now</h2></span>
										</td>
									</tr>
									<tr>
										<td align="center">
											<br><span style="color:red";><?php echo $err_invalid;?></span>
										</td>
									</tr>
									<tr>
										<td align="center">
											<span style="color:white;"><b>Username</b></span>
										</td>
									</tr>
									<tr>
										<td align="left">
											<input type="text" name="uname" value="<?php echo $uname;?>" style="height: 27px;width: 250px">
											<br><small><small><span style="color:yellow"><?php echo $err_uname;?></span></small></small>
										</td>
									</tr>
									<tr>
										<td align="center">
											<br><span style="color:white;"><b>Password</b></span>
										</td>
									</tr>
									<tr>
										<td align="left">
											<input type="password" name="pass"  style="height: 27px;width: 250px">
											<br><small><small><span style="color:yellow"><?php echo $err_pass;?></span></small></small>
										</td>
									</tr>
									<tr>
										<td align="center">
											<br><input type="submit" value="Login" name="login" style="height: 27px;width: 250px;background-color:#ff4e00; border-color:blue;color:white;">
											
										</td>
									</tr>
									<tr>
										<td align="center">
											<span style="color:white";>Create an account, <a href="adminsignup.php">Signup</a></span>
											<br><br><br><br>
										</td>
									</tr>
								</table>
							</center>
						</td>
					</tr>
				</table>
			</center>
		</form>
	</body>
</html>