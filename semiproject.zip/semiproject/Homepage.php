

<?php
	session_start();
	$has_error=false;
	if(!isset($_COOKIE['loggedinuser']))
	{
		header("Location:login.php");
		$has_error=true;
	}
?>


<html>

	<title>Movies,Reviews,News</title>
	<head><center><h1>Movie Review Site</h1></center></head>
	<?php
	if($has_error)
	{
	?>
	<DIV style="position: absolute; top:50px; left:1080px; width:200px; height:25px"><a href="adminsignup.php"><b>Signup</b></a></DIV>
	<DIV style="position: absolute; top:52px; left:1132px; width:200px; height:25px"><b>/</b></a></DIV>
	<DIV style="position: absolute; top:50px; left:1140px; width:200px; height:25px"><a href="login.php"><b>Login</b></a></DIV>
	<?php
	}
	else
	{
	?>
		<DIV style="position: absolute; top:50px; left:1125px;"><b>Welcome </b><span style="color:red";><b><?php echo $_COOKIE['loggedinuser']?></b></span><b>!</b></DIV>
		<DIV style="position: absolute; top:50px; left:1250px; "><a href="login.php"><b>LOGOUT</b></a></DIV>
	<?php
	}
	?>
	
	
	
	<body style="background-color:rgb(233, 230, 230 );">
		<form action="" method="post">
			<table>
				
				<tr>
					<td align="right">
						<center>
							&nbsp &nbsp 
							<button type="button"  style="height:30px; width:100px">Home</button>
							&nbsp <button onClick="parent.location='movies.php'" type="button" style="height:30px; width:100px">Movies</button>
							&nbsp <button onclick="parent.location='news.php'" type="button" style="height:30px; width:100px">News</button>
							&nbsp <button type="button" style="height:30px; width:100px">In Theaters</button>
							&nbsp <button type="button" style="height:30px; width:110px">Comming Soon</button>
							&nbsp <button type="button" style="height:30px; width:100px">Best Movies</button>
							&nbsp <button type="button" style="height:30px; width:100px">Critics</button>
						</center>
					</td>
				</tr>
			</table>
		<br><center><img src="first.jpg" width="1300px" height="300px"/></center>
			
		<center>
			<table bgcolor="#0000">
			
				<tr align="center">
					
					<span style="color:red";><h2>In Spotlight</h2></span>
				</tr>
				<tr>
				
					<td>
						 <br>
						 &nbsp &nbsp
						<a href="movies.php"> <img src="Photo/avenger.jpg" width="150px" height="150px"/> </a>
						 &nbsp  
					</td>
					<td>
						<br>
						 <a href="movies.php"><img src="Photo/burning.jpg" width="150px" height="150px"/></a>
						 &nbsp
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/bewithyou.jpg" width="150px" height="150px"/></a>
						 &nbsp 
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/parasite.jpg" width="150px" height="150px"/></a>
						 &nbsp 
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/premam.jpg" width="150px" height="150px"/></a>
						 &nbsp  
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/memoriesofmurder.jpg" width="150px" height="150px"/></a>
						 &nbsp  
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/morethanblue.jpg" width="150px" height="150px"/></a>
						 &nbsp  
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/arjunreddy.jpg" width="150px" height="150px"/></a>
						 &nbsp &nbsp 
					</td>
					
					
					
				</tr>
				
				<tr>
					<td>
						<center> <span style="color:white";><b>Avengers EndGame</b></span></center>
						<br>
					</td>
					<td>
						<center> <span style="color:white";><b>Burning</b></span></center>
						<br>
					</td>
					<td>
						<center> <span style="color:white";><b>Be With You</b></span></center>
						<br>
					</td>
					<td>
						<center> <span style="color:white";><b>Parasite</b></span></center>
						<br>
					</td>
					<td>
						<center> <span style="color:white";><b>Premam</b></span></center>
						<br>
					</td>
					<td>
						<center> <span style="color:white";><b>Memories of murder</b></span></center>
						<br>
					</td>
					<td>
						<center> <span style="color:white";><b>More Than Blue</b></span></center>
						<br>
					</td>
					<td>
						<center> <span style="color:white";><b>Arjun Reddy</b></span></center>
						<br>
					</td>
					
				</tr>
				
			</table>
		</center>
		
		
			
		
		</form>
	</body>



</html>