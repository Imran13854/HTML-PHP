<html>
	<title>Movies</title>
	<body>
	
		<form>
		
			<center><h1>Hello News</h1></center>
		
		</form>

	</body>

</html>