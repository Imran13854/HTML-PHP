<html>

	<body>
		<?php
		$err_fname="";
		$fname="";
		$err_lname="";
		$lname="";
		$err_email="";
		$email="";
		$err_phone="";
		$phone="";
		$err_address1="";
		$address1="";
		$err_address2="";
		$address2="";
		$err_address3="";
		$address3="";
		$err_address4="";
		$address4="";
		$err_birth="";
		$birth="";
		$err_checkbtn="";
		$checkbtn="";
		if(isset($_POST['submit']))
		{
			
			if(empty($_POST['fname']))
			{
				$err_fname="* First Name Required";
			}
			else
			{			
				$fname=htmlspecialchars($_POST['fname']);
				echo "$fname ";
			}
			if (empty($_POST['lname']))
			{
				$err_lname="*Last name Required";
			}
			else
			{
				$lname=htmlspecialchars($_POST['lname']);
				echo $lname;
			}
			if (empty($_POST['email']))
			{
				$err_email="*Email Required";
			}
			else
			{
				$email=htmlspecialchars($_POST['email']);
				if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
					$err_email = "Invalid email format";
					}
				else{
				echo "<br>$email<br>";}
			}
			if (empty($_POST['phone']))
			{
				$err_phone="*Phone number Required";
			}
			else
			{
				
				$phone=$_POST['phone'];
				
				if (strlen($phone)==11){
				
					echo "$phone <br>";
				}
				else{
					$err_phone="*Invalid Phone number";
				}
			}
			
			
			if (empty($_POST['address1']))
			{
				$err_address1="*Street Address Required";
			}
			else
			{
				$address1=htmlspecialchars($_POST['address1']);
				echo "$address1 <br>";
			}
			if (empty($_POST['address2']))
			{
				$err_address2="*Street Address  line 2 Required";
			}
			else
			{
				$address2=htmlspecialchars($_POST['address2']);
				echo "$address2 <br>";
			}
			if (empty($_POST['address3']))
			{
				$err_address3="*City Required";
			}
			else
			{
				$address3=htmlspecialchars($_POST['address3']);
				echo "$address3 <br>";
			}
			if (empty($_POST['address4']))
			{
				$err_address4="*State Required";
			}
			else
			{
				$address4=htmlspecialchars($_POST['address4']);
				echo "$address4 <br>";
			}
			if (empty($_POST['birth']))
			{
				$err_birth="*Birth date Required";
			}
			else
			{
				$birth=$_POST['birth'];
				
				echo "$birth <br>";
			
		}
			if (empty($_POST['checking']))
			{
				$err_checkbtn="*Checking Required";
			}
			else
			{
				$checkbtn=$_POST['checking'];
				foreach($checkbtn as $check)
				echo "$check <br>";
			
		    }
		}
	?>
	
	
	
	
	
	
	
		<form method="post" action="">
			<br><h2>Club Membership Registration</h2>
			<b>Complete the form below to sign up for our membership service.</b>
			
			<table>
				<tr>
					<td align="left">
						<b>Name</b> &nbsp &nbsp
					</td>
					<td>
					<br><input type="text"  value="<?php echo $fname;?>" name="fname" size="10">
					<input type="text" value="<?php echo $lname;?>" name="lname" size="10">
					<span style="color:red"><?php echo $err_fname;?></span> &nbsp &nbsp
					<span style="color:red"><?php echo $err_lname;?></span>
					<br><b>First Name<b>  &nbsp &nbsp &nbsp &nbsp
					<b>last Name<b>
					</td>
				</tr>
				<tr>
					<td align="left">
						<b>E-mail</b> &nbsp &nbsp
					</td>
					<td>
					<br><input type="text" value="<?php echo $email;?>" name="email" placeholder="ex:myname@example.com">
					<span style="color:red"><?php echo $err_email;?></span>
					<br><b>example@example.com<b>  
					
					</td>
				</tr>
				<tr>
					<td align="left">
						<b>Phone Number:</b> &nbsp &nbsp
					</td>
					<td>
					<br><input type="text" size="6">
					<b>-</b>
					<input type="text" value="<?php echo $phone;?>" name="phone" size="10">
					<span style="color:red"><?php echo $err_phone;?></span>
					<br><b>Area Code<b>  &nbsp &nbsp
					<b>Phone Number<b>
					</td>
					
				</tr>
				<tr>
					<td valign="top">
						<br><b>Address:</b> &nbsp &nbsp
					</td>
					<td>
					<br><input type="text" value="<?php echo $address1;?>" name="address1"  size="20">
					<span style="color:red"><?php echo $err_address1;?></span>
					<br><b> Street Address<b> <br>
					<br><input type="text" value="<?php echo $address2;?>" name="address2" size="20">
					<span style="color:red"><?php echo $err_address2;?></span>
					<br><b> Street Address Line 2<b> <br>
					<br><input type="text" value="<?php echo $address3;?>" name="address3" size="10">
					
					<input type="text" value="<?php echo $address4;?>" name="address4" size="10">
					<span style="color:red"><?php echo $err_address3;?></span> &nbsp &nbsp
					<span style="color:red"><?php echo $err_address4;?></span>
					<br><b> city<b> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
					<b> State / Provience<b>
					</td>
					
				</tr>
				
				<tr>
					<td align="left">
						<br><b>Birth Date:</b>
					</td>
					<td>
						<br><input type="date" value="<?php echo $birth;?>">
						<span style="color:red"><?php echo $err_birth;?></span>
					</td>
				</tr>
				<tr>
					<td valign="top">
						<br><br><b>Where did you hear</b><br>
						<b>about us?</b>
					</td>
					<td>
						<br><br><input type="checkbox" name="checking[]" value="A friend or colleauge"><b>A friend or colleauge</b><br>
						<input type="checkbox" name="checking[]" value="Google"><b>Google</b><br>
						<input type="checkbox" name="checking[]" value="Blog Post"><b>Blog Post</b><br>
						<input type="checkbox" name="checking[]" value="News Article"><b>News Article</b><br>
						<span style="color:red"><?php echo $err_checkbtn;?></span>
					</td>
				</tr>
				
			</table>
		
		<center>
		<input type="submit" name="submit" value="Submit">
		</center>
		
		</form>
	</body>

</html>