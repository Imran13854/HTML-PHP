<?php require_once "../controllers/addAdminController.php";?>
<html>

	<title>Movies</title>
	<head>
		<link rel="stylesheet" type="text/css" href="CSSS/addadmin.css">
		
		<script src="https://kit.fontawesome.com/1e099de9d8.js"></script>
		
	
	</head>
	
	
	
	
	<body>
	<header>
	
	<?php require_once "../controllers/userCheck.php"?>
	
		<form action="" method="post">
			<center>
			<h1>Add Admin</h1>
		</center>
						
						<div class="button">
							<ul>
								<li class="inactive"><a href="Homepage.php">Home</a></li>
								<li class="inactive"><a href="movies.php">Movies</a></li>
								<li class="inactive"><a href="news.php">News</a></li>
								<li class="inactive"><a href="intheater.php">In Theaters</a></li>
								<li class="inactive"><a href="comingsoon.php">Coming soon</a></li>
								<li class="inactive"><a href="bestmovie.php">Best Movies</a></li>
								<?php
								if($_COOKIE['youare']=='1'){?>
								<li class="active"><a href="addadmin.php">Add Admin</a></li>
								
								<li class="inactive"><a href="addreview.php">Add Reviews</a></li>
								<?php } ?>
								<li class="inactive"><a href="about.php">About</a></li>
							</ul>
						</div>
						
				
					<div class="login-box">
					<img src="Photo/avaterlogo3.png" class="avatar">
						<center>
							<h1>Add New Admin</h1>
							<span style="color:green"><?php echo $congratulation;?></span><br>
						</center>
								<table>
									<tr>
										<td>
											<p>First Name</p><small><span style="color:red"><?php echo $err_fname;?></span></small>
											<input type="text" name="fname" value="<?php echo $fname;?>" placeholder="Enter Name name">
											
											<p>Username</p><small><span style="color:red"><?php echo $err_uname;?></span></small>
											<input type="text" name="uname" value="<?php echo $uname;?>" placeholder="Enter Username">
											
											<p>Present Address</p><small><span style="color:red"><?php echo $err_address1;?></span></small>
											<input type="text" name="address1" value="<?php echo $address1;?>" placeholder="Enter Present Address">
											
											<p>City</p><small><span style="color:red"><?php echo $err_city;?></span></small>
											<input type="text" name="city" value="<?php echo $city;?>" placeholder="Enter City">
											
											<p>Zip Code</p><small><span style="color:red"><?php echo $err_zip;?></span></small>
											<input type="text" name="zip" value="<?php echo $zip;?>" placeholder="Enter Zip code">
											
											<p>Password</p><small><span style="color:red"><?php echo $err_pass;?></span></small>
											<input type="password" name="pass" value="<?php echo $pass;?>" placeholder="Enter Password">
										
										</td>
										<td>
											&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
											&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
										</td>
										<td>
											<p>Last Name</p><small><span style="color:red"><?php echo $err_lname;?></span></small>
											<input type="text" name="lname" value="<?php echo $lname;?>" placeholder="Enter Last name">
											
											<p>E-mail</p><small><span style="color:red"><?php echo $err_email;?></span></small>
											<input type="text" name="email" value="<?php echo $email;?>" placeholder="Enter E-mail">
											
											<p>Permanet Address</p><small><span style="color:red"><?php echo $err_address2;?></span></small>
											<input type="text" name="address2" value="<?php echo $address2;?>" placeholder="Enter Permanet Address">
											
											<p>State</p><small><span style="color:red"><?php echo $err_state;?></span></small>
											<input type="text" name="state" value="<?php echo $state;?>" placeholder="Enter State">
											
											<p>Phone Number</p><small><span style="color:red"><?php echo $err_phone;?></span></small>
											<input type="text" name="phone" value="<?php echo $phone;?>" placeholder="Enter Phone Number">
											
											<p>Confirm Password</p><small><span style="color:red"><?php echo $err_confpass;?></span></small>
											<input type="password" name="confpass" value="<?php echo $confpass;?>" placeholder="Re-Enter Password">
										</td>
									</tr>
								</table>
								<center>
									
								</center>
								<center><input type="submit" name="login" value="Submit">
								
								</center>
						
							
					</div>
		
			
		
		</form>
		</header>
	</body>



</html>