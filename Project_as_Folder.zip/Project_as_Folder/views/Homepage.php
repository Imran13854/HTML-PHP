
<html>

	<title>Movies,Reviews,News</title>
	
	<head>
		<link rel="stylesheet" type="text/css" href="CSSS/home.css">
		
		<script src="https://kit.fontawesome.com/1e099de9d8.js"></script>
	</head>
	
	
	
	
	<body>
	<header>
		<?php require_once "../controllers/userCheck.php"?>
		<form action="" method="post">
		<center>
		<h1>Movie review site</h1>
		</center>		
			
			<div class="button">
				
							<ul>
							
								
								<li class="active"><a href="Homepage.php">Home</a></li>
								<li class="inactive"><a href="movies.php">Movies</a></li>
								<li class="inactive"><a href="news.php">News</a></li>
								<li class="inactive"><a href="intheater.php">In Theaters</a></li>
								<li class="inactive"><a href="comingsoon.php">Coming soon</a></li>
								<li class="inactive"><a href="bestmovie.php">Best Movies</a></li>
								<?php
								if($_COOKIE['youare']=='1'){?>
								<li class="inactive"><a href="addadmin.php">Add Admin</a></li>
								
								<li class="inactive"><a href="addreview.php">Add Reviews</a></li>
								<?php } ?>
								<li class="inactive"><a href="about.php">About</a></li>
							</ul>
						</div>
			
				
			<div class="spotlight-box">
			
					<center><h3>In Spotlight</h3></center>
				
			</div>
				
				
		<center>
			<table class="table-box">
				
			
				<tr>
				
					<td>
						 
						
						 <br>
						<a href="movies.php"> <img src="Photo/avenger.jpg" width="150px" height="150px"/> </a>
						 &nbsp  
					</td>
					<td>
						<br>
						 <a href="movies.php"><img src="Photo/burning.jpg" width="150px" height="150px"/></a>
						 &nbsp
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/bewithyou.jpg" width="150px" height="150px"/></a>
						 &nbsp 
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/parasite.jpg" width="150px" height="150px"/></a>
						 &nbsp 
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/premam.jpg" width="150px" height="150px"/></a>
						 &nbsp  
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/memoriesofmurder.jpg" width="150px" height="150px"/></a>
						 &nbsp  
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/morethanblue.jpg" width="150px" height="150px"/></a>
						 &nbsp  
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/arjunreddy.jpg" width="150px" height="150px"/></a>
						 
					</td>
				</tr>
				<tr>
					<td>
						<div class="mname"><center> <span style="color:white";><b>Avengers EndGame</b></span></center></div>
						
					</td>
					<td>
						<div class="mname"><center> <span style="color:white";><b>Burning</b></span></center></div>
						
					</td>
					<td>
						<div class="mname"><center> <span style="color:white";><b>Be With You</b></span></center></div>
						
					</td>
					<td>
						<div class="mname"><center> <span style="color:white";><b>Parasite</b></span></center></div>
						
					</td>
					<td>
						<div class="mname"><center> <span style="color:white";><b>Premam</b></span></center></div>
						
					</td>
					<td>
						<div class="mname"><center> <span style="color:white";><b>Memories of murder</b></span></center></div>
						
					</td>
					<td>
						<div class="mname"><center> <span style="color:white";><b>More Than Blue</b></span></center></div>
						
					</td>
					<td>
						<div class="mname"><center> <span style="color:white";><b>Arjun Reddy</b></span></center></div>
						
					</td>
				</tr>
			</table>
		</center>
	
		</form>
		</header>
	</body>



</html>