
<html>

	<title>Movies</title>
	<head>
		<link rel="stylesheet" type="text/css" href="CSSS/intheater.css">
		<link rel="stylesheet" type="text/css" href="CSSS/commonCategory.css">
		<script src="https://kit.fontawesome.com/1e099de9d8.js"></script>
		
	
	</head>
	
	
	
	
	<body>
	<header>
	<?php require_once "../controllers/userCheck.php"?>
	<center>
			<h1 id="h">In Theaters</h1>
		</center>
	
		<form action="" method="post">
			
						
						<div class="button">
							<ul>
								<li class="inactive"><a href="Homepage.php">Home</a></li>
								<li class="inactive"><a href="movies.php">Movies</a></li>
								<li class="inactive"><a href="news.php">News</a></li>
								<li class="active"><a href="intheater.php">In Theaters</a></li>
								<li class="inactive"><a href="comingsoon.php">Coming soon</a></li>
								<li class="inactive"><a href="bestmovie.php">Best Movies</a></li>
								<?php
								if($_COOKIE['youare']=='1'){?>
								<li class="inactive"><a href="addadmin.php">Add Admin</a></li>
								
								<li class="inactive"><a href="addreview.php">Add Reviews</a></li>
								<?php } ?>
								<li class="inactive"><a href="about.php">About</a></li>
							</ul>
						</div>
						
				<?php require_once "category.php" ?>		
		
		
			
		
		</form>
		</header>
	</body>



</html>