<?php require_once "../controllers/addReviewController.php";?>
<html>

	<title>Add Review</title>
	
	<head>
		<link rel="stylesheet" type="text/css" href="CSSS/addreview.css">
		<script src="https://kit.fontawesome.com/1e099de9d8.js"></script>
	</head>
	
	
	
	
	<body>
	<header>
		<?php require_once "../controllers/userCheck.php"?>
	
		<form method="POST" action="" id="comment" enctype="multipart/form-data">
			<center>
			<h1>Add Review</h1>
			</center>
			
		
				<div class="button">
				
							<ul>
							
						
								<li class="inactive"><a href="Homepage.php">Home</a></li>
								<li class="inactive"><a href="movies.php">Movies</a></li>
								<li class="inactive"><a href="news.php">News</a></li>
								<li class="inactive"><a href="intheater.php">In Theaters</a></li>
								<li class="inactive"><a href="comingsoon.php">Coming soon</a></li>
								<li class="inactive"><a href="bestmovie.php">Best Movies</a></li>
								<?php
								if($_COOKIE['youare']=='1'){?>
								<li class="inactive"><a href="addadmin.php">Add Admin</a></li>
								
								<li class="active"><a href="addreview.php">Add Reviews</a></li>
								<?php } ?>
								<li class="inactive"><a href="about.php">About</a></li>
							</ul>
						</div>
		
				<div class="login-box">
				
				
					
					<center><h1>Add Movie Review</h1></center>
						
						<center><span style="color:red;"><?php echo $err_invalid;?></span></center>
				<table>
					<tr>
						<td align="left"> 
						<p>Movie Name</p>  
						</td>
						<td>
							<input type="text" name="mname" value="<?php echo $mname;?>" placeholder="Enter Movie name">
						</td>
						<td>
							<small><span style="color:yellow"><?php echo $err_mname;?></span></small>
						</td>
					</tr>
					<tr>
						<td align="left"> 
						<p>Director</p>  
						</td>
						<td>
							<input type="text" name="director" value="<?php echo $director;?>" placeholder="Enter Director name">
						</td>
						<td>
							<small><span style="color:yellow"><?php echo $err_director;?></span></small>
						</td>
					</tr>
					
					<tr>
						<td align="left">
						<p>Cast</p>
						</td>
						<td>
						<input type="text" name="cast" value="<?php echo $cast;?>" placeholder="Enter Movie Cast">
						</td>
						<td>
							<small><span style="color:yellow"><?php echo $err_cast;?></span></small>
						</td>
					</tr>
					<tr>
						<td align="left">
							<p>Release Date</p>
						</td>
						<td>
						<select name = "month" style="height: 25px;width: 105px">
							<option>Month</option>
							<?php 
								if($date==1){ ?>
								<option selected="true">
								
								<?php echo $month;?></option>
								<?php } ?>
							<?php
							for($month = 0; $month < 12; $month++){
								echo"<option value = '".$monthlist[$month]."'>".$monthlist[$month]."</option>";
							}
						    ?>
						
						
						</select>
						<select name = "day" style="height: 25px;width: 105px">
							<option>Day</option>
							<?php 
								if($dayy==1){ ?>
								<option selected="true">
								
								<?php echo $day;?></option>
								<?php } ?>
							<?php
							for($day = 1; $day <= 31; $day++){
								echo "<option value = '".$day."'>".$day."</option>";
							}
							?>
						</select>
						<select name = "year" style="height: 25px;width: 105px">
							<option>Year</option>
							<?php 
								if($yearr==1){ ?>
								<option selected="true">
								
								<?php echo $year;?></option>
								<?php } ?>
					
							<?php
							for($year = 2025; $year >= 1900; $year--){
								echo "<option value = '".$year."'>".$year."</option>";
							}
							?>
						</select>	
						</td>
					<td>
						<small><span style="color:red"><?php echo $err_month;?></span></small>
						<small><span style="color:blue"><?php echo $err_day;?></span></small>
						<small><span style="color:orange"><?php echo $err_year;?></span></small>
					</td>
					</tr>
					<tr>
						<td>
							<p>Category</p>
						</td>
						<td>
							<select name="category">
								
								<option selected="true">Choose a Category</option>
								<?php 
								if($cat==1){ ?>
								<option selected="true">
								
								<?php echo $category;?></option>
								<?php } ?>
								<option>English</option>
								<option>Hindi</option>
								<option>Tamil</option>
								<option>Telugu</option>
								<option>Malayalam</option>
								<option>Kannada</option>
								<option>Korean</option>
								<option>Spanish</option>
								<option>Indonesia</option>
								<option>China</option>
							</select>
						</td>
						<td>
							<small><span style="color:yellow"><?php echo $err_category;?></span></small>
						</td>

					</tr>
					<tr>
						<td>
							<p>Genre</p>
						</td>
						<td>
							<select name="genre"  style="width: 172px;">
							
								<option selected="true">Choose a Genre</option>
								<?php 
								if($gen==1){ ?>
								<option selected="true">
								
								<?php echo $genre;?></option>
								<?php } ?>
								<option>Action</option>
								<option>Thriller</option>
								<option>Action,Romantic</option>
								<option>Romantic</option>
								<option>Romantic,Comedy</option>
								<option>Drama,Action </option>
								<option>Biography</option>
								<option>Action,Comedy</option>
								<option>Horror</option>
								<option>Sci-fi</option>
							</select>
						</td>
						<td>
							<small><span style="color:yellow"><?php echo $err_genre;?></span></small>
						</td>
					</tr>
					<tr>
						<td>
							<p>IMDB</p>
						</td>
						<td>
							<input  type="text"  name="imdb" value="<?php echo $imdb;?>" placeholder="Enter IMDB Rating">
						</td>
						<td>
							<small><span style="color:yellow"><?php echo $err_imdb;?></span></small>
						</td>
					</tr>
					<tr>
						<td>
							<p>Cover Photo</p>
						</td>
						<td>
							<input style="color:green; width:200px;" type="file" name="fileToUpload"])">
						</td>
						<td>
							<small><span style="color:yellow"><?php echo $err_img;?></span></small>
						</td>
					</tr>
					<tr>
						<td valign="top">
							<p>Description</p>
						</td>
						<td>
							<textarea style="width:420px; height:300px;"  name="description" placeholder="Enter Movie Description..." form="comment"><?php echo $description;?></textarea>
						</td>
						<td>
							<small><span style="color:yellow"><?php echo $err_description;?></span></small>
						</td>
					</tr>
				</table>
						<center><input type="submit" name="login" value="Submit"></center>
						
					
				</div>
				
			</form>
		</header>
	</body>

</html>