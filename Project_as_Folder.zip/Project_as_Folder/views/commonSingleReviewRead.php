<?php
			
				
				
			if(mysqli_num_rows($reviews) > 0)
			{
				
				while($rows = mysqli_fetch_assoc($reviews))
				{
					
					if($rows["id"]==$pid){
					
					
					$filepath = 'Photo/' . $rows['img'];
					$moviename=$rows["name"];
					
					echo "<center>";
					echo "<td class='image'>"."<img src=$filepath width='300px' height='300px'>"."</td"."<br>";
					echo "<center>"."<p>".$moviename."</p>"."</center>"."</center>";
					
					
					echo "<div class='point'>";
					echo "<table>";
			
					echo "<tr>";
					echo "<td class='name'>"."Name"."</td>";
					echo "<td class='disname'>".": ".$rows["name"]."</td>";
					echo "</tr>";
					
					
					
					echo "<tr>";
					echo "<td class='name'>"."Director"."</td>";
					echo "<td class='disname'>".": ".$rows["director"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Cast"."</td>";
					echo "<td class='disname'>".": ".$rows["cast"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Relase Date"."</td>";
					echo "<td class='disname'>".": ".$rows["month"]." ".$rows["day"].",".$rows["year"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Category"."</td>";
					echo "<td class='disname'>".": ".$rows["category"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Genre"."</td>";
					echo "<td class='disname'>".": ".$rows["genre"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."IMDB"."</td>";
					echo "<td class='disname'>".": ".$rows["imdb"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td valign='top' class='name'>"."Description"."</td>";
					echo "<td class='disname'>".": ".$rows["description"]."</td>";
					echo "</tr>";
					echo "</table>";
					
					echo "</div>";
					
					
					
					}
					
				}
			}
		
		?>
			
					
		<br> <br> <br> <br> <br> <br> <br> <br>
		<div class="comm">Comments</div>
		<?php
			
				
				
			if(mysqli_num_rows($getcomment) > 0)
			{
				
				while($rows = mysqli_fetch_assoc($getcomment))
				{
					
				
					if($rows["mid"]==$pid){
					$user=$rows["user"];
					echo "<div class='comments'>";
					echo "<table>";
			
					echo "<tr>";
					
					echo "<td class='name'>"."<a href='profile.php?id=$user'>".$user."</a>"."</td>";
					echo "</tr>";
					
					
					
					echo "<tr>";
					
					echo "<td class='disname'>"."- ".$rows["comment"]."</td>";
					echo "</tr>";
					
					
					echo "</table>";
					
					echo "</div>";
					
					
					}
					
					
				}
			}
		
	?>				
		
		<div class="comment">
		<center>
			<table>
				<tr>
					<td valign="top">
						<p>Comment</p>
					</td>
					<td>
						<textarea style="width:400px; height:80px;"  name="comment" placeholder="Write Comment..."></textarea>
						<small><span style="color:red"><?php echo $err_comment;?></span></small>
					</td>
				</tr>
			</table>
			<input type="submit" style="width:100px; height:30px;" name="postcomment" value="Post">
		</center>
		</div>
				