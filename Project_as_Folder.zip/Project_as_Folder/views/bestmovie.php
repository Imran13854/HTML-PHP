
<html>

	<title>Movies</title>
	<head>
		<link rel="stylesheet" type="text/css" href="CSSS/movie.css">
		<link rel="stylesheet" type="text/css" href="CSSS/commonCategory.css">
		<script src="https://kit.fontawesome.com/1e099de9d8.js"></script>
		
	
	</head>
	
	
	
	
	<body>
	<header>
	<?php require_once "../controllers/userCheck.php"?>
		
		<form action="" method="post">
			<center>
			<h1 id="h">Best Movies</h1>
		</center>
						
						<div class="button">
							<ul>
								<li class="inactive"><a href="Homepage.php">Home</a></li>
								<li class="inactive"><a href="movies.php">Movies</a></li>
								<li class="inactive"><a href="news.php">News</a></li>
								<li class="inactive"><a href="intheater.php">In Theaters</a></li>
								<li class="inactive"><a href="comingsoon.php">Coming soon</a></li>
								<li class="active"><a href="bestmovie.php">Best Movies</a></li>
								<?php
								if($_COOKIE['youare']=='1'){?>
								<li class="inactive"><a href="addadmin.php">Add Admin</a></li>
								
								<li class="inactive"><a href="addreview.php">Add Reviews</a></li>
								<?php } ?>
								<li class="inactive"><a href="about.php">About</a></li>
							</ul>
						</div>
						
						<div class="tabpos">
							<table bgcolor="#004EA8">
								<tr>
									<td width="2000">
										<div>
											<ul class="cat">
												<li class="H"><a href="allbestreview.php?mid=0">Hindi</a></li>
												<li class="H"><a href="allbestreview.php?mid=1">English</a></li>
												<li class="H"><a href="allbestreview.php?mid=2">Tamil</a></li>
												<li class="H"><a href="allbestreview.php?mid=3">Telugu</a></li>
												<li class="H"><a href="allbestreview.php?mid=4">Malayalam</a></li>
												<li class="H"><a href="allbestreview.php?mid=5">Kannada</a></li>
												<li class="H"><a href="allbestreview.php?mid=6">Korean</a></li>
												<li class="H"><a href="allbestreview.php?mid=7">Spanish</a></li>
												<li class="H"><a href="allbestreview.php?mid=8">Indonesia</a></li>
												<li class="H"><a href="allbestreview.php?mid=9">China</a></li>
												
											</ul>
											
										</div>
									</td>
								</tr>
							</table>
						</div>
						
						
								
		<br> <br> <br> <br> <br> <br> <br> <br>
		<?php
			
			$query="SELECT * FROM addreview ORDER BY id DESC";
			$reviews=get($query);
			
				echo "<center>";
					echo "<h1>"."Best Movie Reviews"."</h1>";
				echo "</center>";	
					
			if(mysqli_num_rows($reviews) > 0)
			{
				
				while($rows = mysqli_fetch_assoc($reviews))
				{
					
					$rating=$rows["imdb"];
					if($rating>=9){
					$filepath = 'Photo/' . $rows['img'];
					$moviename=$rows["name"];
					$id=$rows['id'];
					
					
					echo "<table>";
					echo "<tr>";
					
					echo "<td  class='images'>"."<a href='readbestreview.php?mid=$id'>"."<img src=$filepath width='200px' height='200px'>"."</a>"."<br>".
					"<center>"."<p>".$moviename."</p>"."</center>"."</td>";
					
					
					
					echo "<td>";
					echo "<div class='point'>";
					echo "<table>";
			
					echo "<tr>";
					echo "<td class='name'>"."Name"."</td>";
					echo "<td class='disname'>".": ".$moviename."</td>";
					echo "</tr>";
					
					
					
					echo "<tr>";
					echo "<td class='name'>"."Director"."</td>";
					echo "<td class='disname'>".": ".$rows["director"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Cast"."</td>";
					echo "<td class='disname'>".": ".$rows["cast"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Relase Date"."</td>";
					echo "<td class='disname'>".": ".$rows["month"]." ".$rows["day"].",".$rows["year"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Category"."</td>";
					echo "<td class='disname'>".": ".$rows["category"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Genre"."</td>";
					echo "<td class='disname'>".": ".$rows["genre"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."IMDB"."</td>";
					echo "<td class='disname'>".": ".$rows["imdb"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td valign='top' class='name'>"."Description"."</td>";
					echo "<td class='disname'>".": ".$rows["description"]."</td>";
					echo "</tr>";
					echo "</table>";
					
					echo "</div>";
					echo "</td>";
					echo "</tr>";
					echo "</table>";
					}
				}
			}
		
		?>
						
		
			
		
		</form>
		</header>
	</body>



</html>