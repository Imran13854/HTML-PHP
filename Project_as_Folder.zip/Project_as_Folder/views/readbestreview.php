<?php require_once"../controllers/readReviewController.php"?>
<html>

		
	<title>Movies</title>
	
	<head>
		<link rel="stylesheet" type="text/css" href="CSSS/readreview.css">
		<link rel="stylesheet" type="text/css" href="CSSS/commonCategory.css">
		<script src="https://kit.fontawesome.com/1e099de9d8.js"></script>
	</head>
	
	
	
	
	
		<body>
		<header>
	<?php require_once "../controllers/userCheck.php"?>
		
		<form  action="" method="POST">
			<center>
			<h1>Reviews</h1>
			</center>
						
						<div class="button">
							<ul>
							
								<li class="inactive"><a href="Homepage.php">Home</a></li>
								<li class="inactive"><a href="movies.php">Movies</a></li>
								<li class="inactive"><a href="news.php">News</a></li>
								<li class="inactive"><a href="intheater.php">In Theaters</a></li>
								<li class="inactive"><a href="comingsoon.php">Coming soon</a></li>
								<li class="active"><a href="bestmovie.php">Best Movies</a></li>
								<?php
								if($_COOKIE['youare']=='1'){?>
								<li class="inactive"><a href="addadmin.php">Add Admin</a></li>
								
								<li class="inactive"><a href="addreview.php">Add Reviews</a></li>
								<?php } ?>
								<li class="inactive"><a href="about.php">About</a></li>
							</ul>
						</div>
						
				
					<div class="tabpos">
							<table bgcolor="#299E11">
								<tr>
									<td width="2000">
										<div>
											<ul class="cat">
												<li class="H"><a href="allbestreview.php?mid=0">Hindi</a></li>
												<li class="H"><a href="allbestreview.php?mid=1">English</a></li>
												<li class="H"><a href="allbestreview.php?mid=2">Tamil</a></li>
												<li class="H"><a href="allbestreview.php?mid=3">Telugu</a></li>
												<li class="H"><a href="allbestreview.php?mid=4">Malayalam</a></li>
												<li class="H"><a href="allbestreview.php?mid=5">Kannada</a></li>
												<li class="H"><a href="allbestreview.php?mid=6">Korean</a></li>
												<li class="H"><a href="allbestreview.php?mid=7">Spanish</a></li>
												<li class="H"><a href="allbestreview.php?mid=8">Indonesia</a></li>
												<li class="H"><a href="allbestreview.php?mid=9">China</a></li>
												
											</ul>
											
										</div>
									</td>
								</tr>
							</table>
						</div>
		
		<br> <br> <br> <br> <br> <br> <br> <br>
		
		<?php require_once"commonSingleReviewRead.php"?>
				
		
		</form>
		</header>
	</body>



</html>