<?php
	
	require_once "../models/db_connect.php";
	$admin=0;
	$Name="";
	$Director="";
	$Cast="";
	$month="";
	$day="";
	$year="";
	$Category="";
	$Genre="";
	$IMDb="";
	$Description="";
	$has_error=false;
	
	if(!isset($_COOKIE['loggedinuser']))
	{
		header("Location:login.php");
		$has_error=true;
	}
	$user=$_COOKIE['loggedinuser'];
	$query="SELECT * FROM addreview ORDER BY id DESC";
	$commentquery="SELECT * FROM comment ORDER BY id DESC";
	$reviews=get($query);
	$getcomment=get($commentquery);
	$pid=$_GET['mid'];
	
	
	
	$comment="";
	$err_comment="";
	
	if(isset($_POST['postcomment'])){
		if(empty($_POST['comment'])){
			$err_comment="*Comment Required";
			$has_error=true;
		}
		else{
			$comment=htmlspecialchars($_POST['comment']);
		}
		if(!$has_error){
			$query="INSERT INTO comment (mid,comment,user) 
			VALUES ('$pid','$comment', '$user')";
		
			$com=execute($query);
			
			header("Location:readreview.php?mid=$pid");
			
		}
		
	}
	
	
	
	
?>