<?php
	
	$admin=0;
	$Name="";
	$Director="";
	$Cast="";
	$month="";
	$day="";
	$year="";
	$Category="";
	$Genre="";
	$IMDb="";
	$Description="";
	require_once "../models/db_connect.php";
	$has_error=false;
	if(!isset($_COOKIE['loggedinuser']))
	{
		header("Location:login.php");
		$has_error=true;
	}
	
	$query="SELECT * FROM addreview ORDER BY id DESC";
			$reviews=get($query);
			$pid=$_GET['mid'];	
	
	
?>
