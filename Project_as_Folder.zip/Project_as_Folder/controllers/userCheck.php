<?php
	session_start();
	$admin=0;
	
	
	$has_error=false;
	if(!isset($_COOKIE['loggedinuser']))
	{
		header("Location:login.php");
		$has_error=true;
	}
		
	require_once "../models/db_connect.php";
	
	
	
	
?>
<table>
		<tr>
			<td>
				<DIV class="welcome">
				<?php $user=$_COOKIE["loggedinuser"]?>
				<b>Welcome </b><a href="profile.php?id=<?php echo $user ?>" style="text-decoration: none;"><b id="user"><?php echo $user?></b></a><b>!</b>
				</td>
				<td>
				</DIV>
				<DIV class="logout"><a style="text-decoration: none;"href="login.php"><b id="loghov">Logout</b></a>
				</DIV>
			</td>
		</tr>
	</table>
	
	
	
	
	
	
	
	<div class="search">
				<input type="text" class="search-text" name="" placeholder="Search for Movies,Reviews">
				<a href="#" class="search-btn"><i class="fas fa-search"></i></a>
	</div>	