<?php
	session_start();
	
	if(isset($_COOKIE['loggedinuser']))
	{
		
		setcookie("loggedinuser"," ",time()-240);
	}
?>

<html>
	<?php
		$err_uname="";
		$uname="";
		$err_pass="";
		$pass="";
		$err_invalid="";
		$has_error=false;
		
		if(isset($_POST['login']))
		{
			if(empty($_POST['uname']))
			{
				$err_uname="*Username Required";
				$has_error=true;
			}
			else
			{
				$uname=htmlspecialchars($_POST['uname']);
				
			}
			if(empty($_POST['pass']))
			{
				$err_pass="*Password Required";
				$has_error=true;
			}
			else
			{
				$pass=htmlspecialchars($_POST['pass']);
				
			}
			if(!$has_error)
			{
				$xml=simplexml_load_file("login.xml");
			
		
				for($i=0;$i<count($xml->admin);$i++)
				{
					$name = $xml->admin[$i]->name;
					$pas = $xml->admin[$i]->pass;
					if($uname == $name && $pass== $pas)
					{
					session_start();
					setcookie("loggedinuser",$uname,time()+30000);
					//$_SESSION["loggedinuser"]=$uname;
					header("Location:Homepage.php");
					$c=0;
					}
					else
					{
						$c=1;
					}
				}
				for($i=0;$i<count($xml->user);$i++)
				{
					$name = $xml->user[$i]->name;
					$pas = $xml->user[$i]->pass;
					if($uname == $name && $pass== $pas)
					{
						session_start();
						setcookie("loggedinuser",$uname,time()+30000);
						//$_SESSION["loggedinuser"]=$uname;
						header("Location:Homepage.php");
						$c=0;
					}
					else
					{
						$c=1;
					}
				}
				if($c==1)
				{
					$err_invalid="Invalid Username Password";
					//echo $err_invalid;
				}
			}
		}
	
	?>

	<title>Login</title>
	<head>
		<link rel="stylesheet" type="text/css" href="CSSS/login.css">
	
	</head>

	<body>
		
			<header>
				<div class="login-box">
				<img src="avaterlogo2.png" class="avatar">
					
					<h1>Login Here</h1>
						<form method="POST" action="">
						<center><span style="color:red;"><?php echo $err_invalid;?></span></center>
						<p>Username</p><small><span style="color:yellow"><?php echo $err_uname;?></span></small>
						<input type="text" name="uname" value="<?php echo $uname;?>" placeholder="Enter Username">
						
						<p>Password</p><small><span style="color:yellow"><?php echo $err_pass;?></span></small>
						<input type="password" name="pass" placeholder="Enter Password">
						<input type="submit" name="login" value="Login">
						<center>
						<a href="#">Forget Password</a>
						<br><a href="adminsignup.php">Don't have an account</a>
						</center>
						</form>
					
					
				</div>
			</header>
		
    </body>
</html>