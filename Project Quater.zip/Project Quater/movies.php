
<html>

	<title>Movies</title>
	
	<head>
		<link rel="stylesheet" type="text/css" href="CSSS/movie.css">
		<script src="https://kit.fontawesome.com/1e099de9d8.js"></script>
	</head>
	
	
	
	
	
		<body>
		<header>
		<form  action="" method="post">
			
			<h1 id="h">Movies</h1>
	
						
						<div class="button">
							<ul>
							<br><br>
								<li class="inactive"><a href="Homepage.php">Home</a></li>
								<li class="active"><a href="movies.php">Movies</a></li>
								<li class="inactive"><a href="news.php">News</a></li>
								<li class="inactive"><a href="intheater.php">In Theaters</a></li>
								<li class="inactive"><a href="comingsoon.php">Coming soon</a></li>
								<li class="inactive"><a href="bestmovie.php">Best Movies</a></li>
								<li class="inactive"><a href="critic.php">Critics</a></li>
								<li class="inactive"><a href="about.php">About</a></li>
							</ul>
						</div>
						
						
						
						<div class="tabpos">
							<table bgcolor="#299E11">
								<tr>
									<td width="720">
										<div>
											<ul class="cat">
												<li class="H"><a href="">Hindi</a></li>
												<li class="H"><a href="">English</a></li>
												<li class="H"><a href="">Tamil</a></li>
												<li class="H"><a href="">Telugu</a></li>
												<li class="H"><a href="">Malayalam</a></li>
												<li class="H"><a href="">Kannada</a></li>
												
											</ul>
											
										</div>
									</td>
								</tr>
							</table>
						</div>
						
				
		
		<div class="search">
			<input type="text" class="search-text" name="" placeholder="Search for Movies,Reviews">
				<a href="#" class="search-btn"><i class="fas fa-search"></i></a>
		</div>
		
		</form>
		</header>
	</body>



</html>