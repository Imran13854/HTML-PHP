<html>
     <body>
	 
	 
	 
	 <html>

	<body>
		<?php
		$err_movieName="";
		$movieName="";
		
		$err_moviecast="";
		$moviecast="";
		
		$err_moviereleasedate="";
		$moviereleasedate="";
		
		
		$err_moviedescription="";
		$moviedescription="";
		
		if(isset($_POST['submit']))
		{
			
			if(empty($_POST['movieName']))
			{
				$err_movieName="* movieName Required";
			}
			else
			{			
				$movieName=htmlspecialchars($_POST['movieName']);
				
			}
		
			
			if(empty($_POST['moviecast']))
			{
				$err_moviecast="*moviecast Required";
			}
			else
			{			
				$moviecast=htmlspecialchars($_POST['moviecast']);
				
			}
			if (empty($_POST['moviecast']))
			{
				$err_moviecast="*moviecast";
			}
			
			}
			if(empty($_POST['moviereleasedate']))
			{
				$err_moviereleasedate="*moviereleasedate Required";
			}
			else
			{
				$month=htmlspecialchars($_POST['moviereleasedate']);
				
			}
			
			
		
			if(empty($_POST['moviedescription']))
			{
				$err_moviedescription="* moviedescription Required";
			}
			else
			{			
				$moviename=htmlspecialchars($_POST['moviedescription']);
				
			}
			?>
			
			
			<title>Movie Rating</title>
			<center><br><h1> MOVIE RATING</h1></center>
		<br> 
   <form method="POST" action="">
			<center>
    
 <table>
     
     
 <tr>
                <td> movieName:</td>  
   <td> <input type="text" name="movieName" value="<?php echo $movieName;?>"></td>  
   <span style="color:red"><?php echo $err_movieName;?></span>
 </tr>
 
  <tr>
                <td> movie cast:</td>  
   <td> <input type="text" name="moviecast" value="<?php echo $moviecast;?>" ></td>  
   <span style="color:red"><?php echo $err_moviecast;?></span>
 </tr>
 
 
 <tr>
 
 <td>movie release date:

 
  <select name = "month" style="height: 25px;width: 81px">
											<option>Month</option>
											<?php
												for($month = 1; $month <= 12; $month++){
												echo"<option value = '".$month."'>".$month."</option>";
												}
											?>
											<br><small><small><span style="color:yellow"><?php echo $err_month;?></span></small></small>
										</select>
										<select name = "day" style="height: 25px;width: 81px">
											<option>Day</option>
											<?php
												for($day = 1; $day <= 31; $day++){
												   echo "<option value = '".$day."'>".$day."</option>";
												}
										   ?>
										</select>
										<select name = "Year" style="height: 25px;width: 81px">
											<option>Year</option>
											<?php
												for($year = 2019; $year >= 1900; $year--){
												   echo "<option value = '".$year."'>".$year."</option>";
												}
										   ?>
										</select>
										
 </tr>
 
  <tr>
                <td> movie description</td>  
   <td> <input type="text" name="moviedescription" value="<?php echo $moviedescription;?>"></td>  
   <span style="color:red"><?php echo $err_moviedescription;?></span>
 </tr>
              

            </table>
			<center>
		<input type="submit" name="submit" value="Submit">
		</center>


     

    </table>
	 </form>

</body>






</html>