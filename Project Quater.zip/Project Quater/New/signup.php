<!DOCTYPE html>
<html>
<head>
	<title>SignUp</title>
</head>
<body>
	<center>
	<form method="POST" action="regcheck.php">
		<fieldset style="width:450px">
            <legend><b>SIGNUP</b></legend>
			<table style="padding:10px">
				<tr>
					<td>First Name</td>
					<td><b>:</b> <input type="text" name="name"></td>
				</tr>
				<tr>
					<td>Last Name</td>
					<td><b>:</b> <input type="text" name="name"></td>
				</tr>
				<tr>
					<td> User Id</td>
					<td> <b>:</b> <input type="text" name="id" placeholder="Enter user id"><br></td>
				</tr>
				<tr>
				<tr>
					<td> Email </td>
					<td> <b>:</b> <input type="text" name="id" placeholder="Enter email id"><br></td>
				</tr>
				<tr>
					<td>Password</td>
					<td><b>:</b> <input type="password" name="pass"  placeholder="Enter password"></td>
				</tr>
				<tr>
					<td>Confirm Password</td>
					<td><b>:</b> <input type="password" name="conpass"  placeholder="Re-enter password" ></td>
				</tr>
				
				<tr>
		            <td>Phone Number</td>
		            <td><b>:</b> <input type="text" name="Phoneno" placeholder="Enter your phone Number"></td>
		        </tr>
				<tr>
		            <td> <label>Date of birth</label></td>
		            <td><b>:</b> <input type="date" name="date" placeholder="Date of Birth"></td>
		   
		        </tr>
                <tr>			
					<td><input type="submit" value="Sign Up" ></td>
					<td>Already have an account?<a href="login.php"> Sign In</a></td>
				</tr>
			</table>
        </fieldset>
	</form>
	</center>	
</body>
</html>

