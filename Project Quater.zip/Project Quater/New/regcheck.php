<?php
	session_start();
	
	if(isset($_REQUEST['submit'])){
        $name = $_REQUEST['name'];
		$id = $_REQUEST['id'];
		$pass =  $_REQUEST['pass'];
        $conpass = $_REQUEST['conpass'];

        if(empty(trim($id)) || empty(trim($pass)) || empty(trim($conpass)) || empty(trim($name))){
            echo "Null submission found!";
        }else{
            echo "Registration Successful";
            $myfile = fopen("user.txt", "a");
            $txt = $id."|".$pass."\n";
            fwrite($myfile, $txt);
            fclose($myfile);
        }
	}
?>