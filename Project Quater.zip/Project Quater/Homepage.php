

<?php
	session_start();
	$has_error=false;
	if(!isset($_COOKIE['loggedinuser']))
	{
		header("Location:login.php");
		$has_error=true;
	}
?>


<html>

	<title>Movies,Reviews,News</title>
	
	<head>
		<link rel="stylesheet" type="text/css" href="CSSS/home.css">
		<script src="https://kit.fontawesome.com/1e099de9d8.js"></script>
	</head>
	
	
	
	
	<body>
	<header>
	
	
	
	
	<?php
	if($has_error)
	{
	?>
	<DIV style="position: absolute; top:50px; left:1080px; width:200px; height:25px"><a href="adminsignup.php"><b>Signup</b></a></DIV>
	<DIV style="position: absolute; top:52px; left:1132px; width:200px; height:25px"><b>/</b></a></DIV>
	<DIV style="position: absolute; top:50px; left:1140px; width:200px; height:25px"><a href="login.php"><b>Login</b></a></DIV>
	<?php
	}
	else
	{
	?>
	
	<table>
		<tr>
			<td>
		<DIV class="welcome">
		<b>Welcome </b><a href="movies.php" style="text-decoration: none;"><b id="user"><?php echo $_COOKIE['loggedinuser']?></b></a><b>!</b>
		</td>
		<td>
		</DIV>
		<DIV class="logout"><a style="text-decoration: none;"href="login.php"><b id="loghov">Logout</b></a>
		</DIV>
		</td>
		</tr>
		</table>
	<?php
	}
	?>
	
	
		
		<form action="" method="post">
		
		<h1>Movie review site</h1>
				
			
			<div class="button">
				
							<ul>
							
								<br><br>
								<li class="active"><a href="Homepage.php">Home</a></li>
								<li class="inactive"><a href="movies.php">Movies</a></li>
								<li class="inactive"><a href="news.php">News</a></li>
								<li class="inactive"><a href="intheater.php">In Theaters</a></li>
								<li class="inactive"><a href="comingsoon.php">Coming soon</a></li>
								<li class="inactive"><a href="bestmovie.php">Best Movies</a></li>
								<li class="inactive"><a href="critic.php">Critics</a></li>
								<li class="inactive"><a href="about.php">About</a></li>
							</ul>
						</div>
			
			<div class="spotlight1-box">
			
							
			</div>	
			<br><br><br><div class="spotlight-box">
			
					<center><h3>In Spotlight</h3></center>
				
			</div>
				
				
		<center>
			<table class="table-box">
				
			
				<tr>
				
					<td>
						 
						
						 <br>
						<a href="movies.php"> <img src="Photo/avenger.jpg" width="150px" height="150px"/> </a>
						 &nbsp  
					</td>
					<td>
						<br>
						 <a href="movies.php"><img src="Photo/burning.jpg" width="150px" height="150px"/></a>
						 &nbsp
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/bewithyou.jpg" width="150px" height="150px"/></a>
						 &nbsp 
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/parasite.jpg" width="150px" height="150px"/></a>
						 &nbsp 
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/premam.jpg" width="150px" height="150px"/></a>
						 &nbsp  
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/memoriesofmurder.jpg" width="150px" height="150px"/></a>
						 &nbsp  
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/morethanblue.jpg" width="150px" height="150px"/></a>
						 &nbsp  
					</td>
					<td>
						<br>
						  <a href="movies.php"><img src="Photo/arjunreddy.jpg" width="150px" height="150px"/></a>
						 
					</td>
				</tr>
				<tr>
					<td>
						<div class="mname"><center> <span style="color:white";><b>Avengers EndGame</b></span></center></div>
						
					</td>
					<td>
						<div class="mname"><center> <span style="color:white";><b>Burning</b></span></center></div>
						
					</td>
					<td>
						<div class="mname"><center> <span style="color:white";><b>Be With You</b></span></center></div>
						
					</td>
					<td>
						<div class="mname"><center> <span style="color:white";><b>Parasite</b></span></center></div>
						
					</td>
					<td>
						<div class="mname"><center> <span style="color:white";><b>Premam</b></span></center></div>
						
					</td>
					<td>
						<div class="mname"><center> <span style="color:white";><b>Memories of murder</b></span></center></div>
						
					</td>
					<td>
						<div class="mname"><center> <span style="color:white";><b>More Than Blue</b></span></center></div>
						
					</td>
					<td>
						<div class="mname"><center> <span style="color:white";><b>Arjun Reddy</b></span></center></div>
						
					</td>
				</tr>
			</table>
		</center>
		<div class="search">
			<input type="text" class="search-text" name="" placeholder="Search for Movies,Reviews">
			<a href="#" class="search-btn"><i class="fas fa-search"></i>
            </a>
		</div>
		
		</form>
		</header>
	</body>



</html>